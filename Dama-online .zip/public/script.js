const socket = io();

const boardEl = document.getElementById("board");
const statusEl = document.getElementById("status");

let board = [];
let selected = null;
let room = null;

socket.on("waiting", () => {
    statusEl.innerText = "Aguardando outro jogador...";
});

socket.on("start", (data) => {
    room = data.room;
    statusEl.innerText = "Partida iniciada!";
    initBoard();
});

socket.on("move", (move) => {
    applyMove(move);
    draw();
});

function initBoard() {
    for (let r = 0; r < 8; r++) {
        board[r] = [];
        for (let c = 0; c < 8; c++) {
            board[r][c] = null;

            if ((r + c) % 2) {
                if (r < 3) board[r][c] = { color: "blue", king: false };
                if (r > 4) board[r][c] = { color: "red", king: false };
            }
        }
    }
    draw();
}

function draw() {
    boardEl.innerHTML = "";

    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const cell = document.createElement("div");
            cell.className = "cell " + ((r + c) % 2 ? "dark" : "light");

            cell.onclick = () => click(r, c);

            if (board[r][c]) {
                const p = document.createElement("div");
                p.className = "piece " + board[r][c].color;
                if (board[r][c].king) p.classList.add("king");
                cell.appendChild(p);
            }

            boardEl.appendChild(cell);
        }
    }
}

function click(r, c) {
    if (!selected) {
        selected = { r, c };
    } else {
        const move = { from: selected, to: { r, c } };
        applyMove(move);
        socket.emit("move", { room, move });
        selected = null;
    }
}

function applyMove(move) {
    const { from, to } = move;

    board[to.r][to.c] = board[from.r][from.c];
    board[from.r][from.c] = null;

    // virar dama
    const piece = board[to.r][to.c];
    if (piece.color === "red" && to.r === 0) piece.king = true;
    if (piece.color === "blue" && to.r === 7) piece.king = true;
}